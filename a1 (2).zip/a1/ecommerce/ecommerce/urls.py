"""ecommerce URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from ventas.views import inicio, articulo, cliente, crearCliente, venta, pagosxpagar, pagos, \
    cuentasxpagar, registro, consulta, nuevoregistro, cuentasxpagar2, pagos2, pagos3, pagos4, pagos5, \
    pagos6, pagos7, pagos8, pagos9, tablePagos1, tablePagos2, intereses, Interes
from django.conf.urls.static import static
from ecommerce import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', inicio, name='inicio'),
    path('articulo/', articulo, name='articulo'),
    path('cliente/', cliente, name='cliente'),
    path('crearcliente/', crearCliente, name='crearcliente'),
    path('venta/', venta, name='venta'),
    path('pagosxpagar/', pagosxpagar, name='pagosxpagar'),
    path('pagos/', pagos, name='pagos'),
    path('crearpago/', crearCliente, name='crearcliente'),
    path('cuentasxpagar/', cuentasxpagar, name='cuentasxpagar'),
    path('cuentasxpagar2/', cuentasxpagar2, name='cuentasxpagar2'),
    path('crearregistro/', registro, name='crearregistro'),
    path('consulta/', consulta, name='consulta'),
    path('nuevoregistro/', nuevoregistro, name='nuevoregistro'),
    path('pagos2/', pagos2, name='pagos2'),
    path('pagos3/', pagos3, name='pagos3'),
    path('pagos4/', pagos4, name='pagos4'),
    path('pagos5/', pagos5, name='pagos5'),
    path('pagos6/', pagos6, name='pagos6'),
    path('pagos7/', pagos7, name='pagos7'),
    path('pagos8/', pagos8, name='pagos8'),
    path('pagos9/', pagos9, name='pagos9'),
    path('tablePagos1/', tablePagos1, name='tablePagos1'),
    path('tablePagos2/', tablePagos2, name='tablePagos2'),
    path('Interes/', Interes, name='Interes'),
    path('intereses/', intereses, name='intereses'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)