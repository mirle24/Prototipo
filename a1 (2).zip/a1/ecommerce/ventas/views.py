from django.shortcuts import HttpResponse
from django.shortcuts import render
html_base = """
 <h1>Shopping Car</h1>
 <ul>
   <li><a href="/">Inicio</a></li>
   <li><a href="/articulo/">Articulos</a></li>
   <li><a href="/cliente/">Clientes</a></li>
   <li><a href="/venta/">Ventas</a></li>
   <li><a href="/pagos/">Pagos</a></li>
   <li><a href="/pagosxpagar/">Pagos</a></li>
   
 </li>
"""
def inicio(request):
    data = {
        'titulo':"Inicio"
    }
    return render(request,'base.html',data)


def articulo(request):
  return HttpResponse(html_base+
    """<h2>Mantenimiento de Articulo</h2>
       <p>List de articulos</p>""")

def cliente(request):
  data = {
      'titulo':'GESTION DE CLIENTES',
      'crear_url': '/crearcliente',
      'listar_url': '/cliente',
  }
  return render(request, "ventas/clientes/listCliente.html",data)

def crearCliente(request):
  data = {
      'titulo':'MANTENIMIENTO DE CLIENTES',
      'crear_url':'/crearcliente',
      'action':'add',
      'listar_url': '/cliente',
  }
  return render(request, "ventas/clientes/formCliente.html",data)

def venta(request):
  data = {
        'titulo': "Inicio"
  }
  return render(request, "ventas/ventas.html",data)

def pagos(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago.html",data)

def pagos2(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago2.html",data)

def pagos3(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago3.html", data)
def pagos4(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago4.html", data)

def pagos5(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago5.html", data)

def pagos6(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago6.html", data)

def pagos7(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago7.html", data)

def pagos8(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago8.html", data)

def pagos9(request):
  data = {
      'titulo':'GESTION DE PAGOS',
      'crear_urls': '/crearpago',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/listPago9.html", data)

def crearPago(request):
  data = {
      'titulo':'MANTENIMIENTO DE DATOS',
      'crear_urls':'/crearpago',
      'action':'add',
      'listar_urls': '/pago',
  }
  return render(request, "CuentasPorPagar/Pagos/formPagos.html",data)

def pagosxpagar(request):
  data = {
        'titulo': "Inicio"
  }
  return render(request, "CuentasPorPagar/Pagos.html", data)

def cuentasxpagar(request):
  data = {
        'titulo': "Inicio"
  }
  return render(request, "CuentasPorPagar/Pagar/cuentasxpagar.html",data)
def registro(request):
  data = {
    'titulo': 'MANTENIMIENTO DE DATOS',
  }
  return render(request, "CuentasPorPagar/registro.html",data)
def consulta(request):
    data = {
        'titulo': 'CONSULTA DE DATOS',
    }
    return render(request, "CuentasPorPagar/Pagar/consultaPagar.html", data)
def nuevoregistro(request):
    data = {
        'titulo': 'REGISTRO DE DATOS',
    }
    return render(request, "CuentasPorPagar/Pagar/nuevoregistro.html", data)
def cuentasxpagar2(request):
  data = {
        'titulo': "Inicio"
  }
  return render(request, "CuentasPorPagar/Pagar/cuentasxpagar2.html",data)
def tablePagos1(request):
  data = {
        'titulo': "Pagos"
  }
  return render(request, "CuentasPorPagar/Pagos/tablePagos1.html", data)
def tablePagos2(request):
  data = {
        'titulo': "Pagos"
  }
  return render(request, "CuentasPorPagar/Pagos/tablePagos2.html", data)

def intereses(request):
  data = {
        'titulo': "Intereses"
  }
  return render(request, "CuentasPorPagar/Pagos/intereses.html", data)
def Interes(request):
  data = {
        'titulo': "Intereses"
  }
  return render(request, "CuentasPorPagar/Pagos/Interes.html", data)