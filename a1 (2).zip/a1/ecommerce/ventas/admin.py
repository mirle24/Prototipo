from django.contrib import admin
from .models import Grupo,Articulo
admin.site.register(Grupo)
admin.site.register(Articulo)
